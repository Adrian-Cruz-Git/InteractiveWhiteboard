import { createContext } from "react";

// Context only, no logic here
export const AuthContext = createContext(null);
